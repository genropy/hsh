--
-- PostgreSQL database dump
--

-- Dumped from database version 11.8
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: adm; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA adm;


ALTER SCHEMA adm OWNER TO postgres;

--
-- Name: base; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA base;


ALTER SCHEMA base OWNER TO postgres;

--
-- Name: sys; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sys;


ALTER SCHEMA sys OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: adm_access_group; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_access_group (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character varying(10) NOT NULL,
    description character varying(30),
    allowed_ip text
);


ALTER TABLE adm.adm_access_group OWNER TO postgres;

--
-- Name: adm_audit; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_audit (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    tablename text,
    event character(1),
    username text,
    record_pkey text,
    version bigint,
    data text,
    transaction_id text
);


ALTER TABLE adm.adm_audit OWNER TO postgres;

--
-- Name: adm_authorization; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_authorization (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character varying(8) NOT NULL,
    user_id character(22),
    use_ts timestamp without time zone,
    used_by text,
    note text,
    usage_scope text,
    remaining_usages bigint,
    expiry_date date
);


ALTER TABLE adm.adm_authorization OWNER TO postgres;

--
-- Name: adm_backup; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_backup (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    name text,
    start_ts timestamp without time zone,
    end_ts timestamp without time zone
);


ALTER TABLE adm.adm_backup OWNER TO postgres;

--
-- Name: adm_ckstyle; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_ckstyle (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    name text,
    element text,
    styles text,
    attributes text,
    stylegroup text
);


ALTER TABLE adm.adm_ckstyle OWNER TO postgres;

--
-- Name: adm_connection; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_connection (
    id character(22) NOT NULL,
    userid character(22),
    username character varying(32),
    ip character varying(15),
    start_ts timestamp without time zone,
    end_ts timestamp without time zone,
    end_reason character varying(12),
    user_agent text
);


ALTER TABLE adm.adm_connection OWNER TO postgres;

--
-- Name: adm_counter; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_counter (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    codekey character varying(80) NOT NULL,
    code character varying(12),
    pkg character varying(12),
    tbl character varying(30),
    fld character varying(30),
    period character varying(10),
    counter bigint,
    last_used date,
    holes text,
    errors text
);


ALTER TABLE adm.adm_counter OWNER TO postgres;

--
-- Name: adm_day; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_day (
    date date NOT NULL,
    weekday bigint,
    is_holyday boolean
);


ALTER TABLE adm.adm_day OWNER TO postgres;

--
-- Name: adm_group; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_group (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    _row_count bigint,
    __ins_user text,
    code character varying(15) NOT NULL,
    description text,
    custom_menu text,
    rootpage text
);


ALTER TABLE adm.adm_group OWNER TO postgres;

--
-- Name: adm_htag; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_htag (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    parent_id character(22),
    code text,
    hierarchical_code text,
    _parent_h_code text,
    description text,
    hierarchical_description text,
    _parent_h_description text,
    hierarchical_pkey text,
    _parent_h_pkey text,
    __ins_user text,
    __syscode character varying(20),
    isreserved boolean,
    note text
);


ALTER TABLE adm.adm_htag OWNER TO postgres;

--
-- Name: adm_htmltemplate; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_htmltemplate (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    name text,
    username text,
    version text,
    type_code character varying(15),
    data text,
    center_height integer,
    center_width integer,
    based_on character(22),
    next_letterhead_id character(22)
);


ALTER TABLE adm.adm_htmltemplate OWNER TO postgres;

--
-- Name: adm_htmltemplate_atc; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_htmltemplate_atc (
    id character(22) NOT NULL,
    __del_ts timestamp without time zone,
    _row_count bigint,
    __ins_user text,
    filepath text,
    external_url text,
    description text,
    mimetype text,
    text_content text,
    info text,
    is_foreign_document boolean,
    maintable_id character(22)
);


ALTER TABLE adm.adm_htmltemplate_atc OWNER TO postgres;

--
-- Name: adm_install_checklist; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_install_checklist (
    __del_ts timestamp without time zone,
    __ins_user text,
    name text,
    description text,
    pkg character varying(20),
    checked boolean,
    check_ts timestamp without time zone,
    check_user character varying(30),
    annotations text,
    doc_url text
);


ALTER TABLE adm.adm_install_checklist OWNER TO postgres;

--
-- Name: adm_language; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_language (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    _row_count bigint,
    __ins_user text,
    code character varying(2) NOT NULL,
    name text
);


ALTER TABLE adm.adm_language OWNER TO postgres;

--
-- Name: adm_letterhead_type; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_letterhead_type (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character varying(15) NOT NULL,
    description text
);


ALTER TABLE adm.adm_letterhead_type OWNER TO postgres;

--
-- Name: adm_menu; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_menu (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    parent_id character(22),
    label text,
    hierarchical_label text,
    _parent_h_label text,
    hierarchical_pkey text,
    _parent_h_pkey text,
    _h_count text,
    _parent_h_count text,
    _row_count bigint,
    __ins_user text,
    tags text,
    summary text,
    ts_import timestamp without time zone,
    page_id character(22)
);


ALTER TABLE adm.adm_menu OWNER TO postgres;

--
-- Name: adm_menu_page; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_menu_page (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    label text,
    filepath text,
    tbl text,
    pkg text,
    metadata text
);


ALTER TABLE adm.adm_menu_page OWNER TO postgres;

--
-- Name: adm_notification; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_notification (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    title text,
    template text,
    confirm_label text,
    tag_rule text,
    all_users boolean,
    letterhead_id character(22)
);


ALTER TABLE adm.adm_notification OWNER TO postgres;

--
-- Name: adm_pkginfo; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_pkginfo (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    pkgid character varying(50) NOT NULL,
    prj character varying(50)
);


ALTER TABLE adm.adm_pkginfo OWNER TO postgres;

--
-- Name: adm_preference; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_preference (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code character(12) NOT NULL,
    data text
);


ALTER TABLE adm.adm_preference OWNER TO postgres;

--
-- Name: adm_record_tag; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_record_tag (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    tablename text,
    tag text,
    description text
);


ALTER TABLE adm.adm_record_tag OWNER TO postgres;

--
-- Name: adm_sent_email; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_sent_email (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    code text,
    tbl text,
    mail_address text,
    sent_ts timestamp without time zone,
    record_id text
);


ALTER TABLE adm.adm_sent_email OWNER TO postgres;

--
-- Name: adm_served_page; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_served_page (
    page_id character(22) NOT NULL,
    pagename text,
    connection_id character(22),
    start_ts timestamp without time zone,
    end_ts timestamp without time zone,
    end_reason character varying(12)
);


ALTER TABLE adm.adm_served_page OWNER TO postgres;

--
-- Name: adm_shortcut; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_shortcut (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    _row_count bigint,
    __ins_user text,
    keycode character varying(10) NOT NULL,
    phrase text,
    groupcode character varying(20)
);


ALTER TABLE adm.adm_shortcut OWNER TO postgres;

--
-- Name: adm_tblinfo; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_tblinfo (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    tblid character varying(50) NOT NULL,
    pkgid character varying(50),
    description character varying(50)
);


ALTER TABLE adm.adm_tblinfo OWNER TO postgres;

--
-- Name: adm_tblinfo_item; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_tblinfo_item (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    info_key character varying(50) NOT NULL,
    code character varying(50),
    description character varying(50),
    item_type character varying(5),
    data text,
    tblid character varying(50)
);


ALTER TABLE adm.adm_tblinfo_item OWNER TO postgres;

--
-- Name: adm_user; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_user (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __rec_md5 text,
    __ins_user text,
    username character varying(32),
    email text,
    mobile text,
    firstname text,
    lastname text,
    registration_date date,
    auth_tags text,
    status character varying(4),
    md5pwd character varying(65),
    locale character varying(12),
    preferences text,
    menu_root_id character(22),
    avatar_rootpage text,
    sms_login boolean,
    sms_number text,
    group_code character varying(15),
    custom_menu text
);


ALTER TABLE adm.adm_user OWNER TO postgres;

--
-- Name: adm_user_access_group; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_user_access_group (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    user_id character(22),
    access_group_code character varying(10)
);


ALTER TABLE adm.adm_user_access_group OWNER TO postgres;

--
-- Name: adm_user_config; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_user_config (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    ruleid character varying(80) NOT NULL,
    user_group character varying(15),
    username character varying(32),
    pkgid character varying(30),
    tblid character varying(30),
    data text
);


ALTER TABLE adm.adm_user_config OWNER TO postgres;

--
-- Name: adm_user_notification; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_user_notification (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    user_id character(22),
    notification_id character(22),
    confirmed boolean
);


ALTER TABLE adm.adm_user_notification OWNER TO postgres;

--
-- Name: adm_user_tag; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_user_tag (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    group_code character varying(15),
    user_id character(22),
    tag_id character(22)
);


ALTER TABLE adm.adm_user_tag OWNER TO postgres;

--
-- Name: adm_userobject; Type: TABLE; Schema: adm; Owner: postgres
--

CREATE TABLE adm.adm_userobject (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    identifier character varying(120),
    code character varying(40),
    objtype character varying(20),
    pkg character varying(50),
    tbl character varying(50),
    userid character varying(50),
    description character varying(50),
    notes text,
    data text,
    authtags text,
    private boolean,
    quicklist boolean,
    flags text,
    required_pkg text,
    preview text
);


ALTER TABLE adm.adm_userobject OWNER TO postgres;

--
-- Name: base_casa; Type: TABLE; Schema: base; Owner: postgres
--

CREATE TABLE base.base_casa (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    nome text,
    descrizione text
);


ALTER TABLE base.base_casa OWNER TO postgres;

--
-- Name: base_locazione; Type: TABLE; Schema: base; Owner: postgres
--

CREATE TABLE base.base_locazione (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    parent_id character(22),
    nome text,
    hierarchical_nome text,
    _parent_h_nome text,
    hierarchical_pkey text,
    _parent_h_pkey text,
    _h_count text,
    _parent_h_count text,
    _row_count bigint,
    __ins_user text,
    df_fields text,
    df_fbcolumns bigint,
    df_custom_templates text,
    df_colswidth text,
    descrizione text,
    casa_id character(22)
);


ALTER TABLE base.base_locazione OWNER TO postgres;

--
-- Name: base_oggetto; Type: TABLE; Schema: base; Owner: postgres
--

CREATE TABLE base.base_oggetto (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    nome text,
    anno_acquisto integer,
    foto text,
    locazione_id character(22),
    categoria_id character(22),
    casa_id character(22),
    posto_id character(22),
    quantita character varying(2)
);


ALTER TABLE base.base_oggetto OWNER TO postgres;

--
-- Name: base_oggetto_categoria; Type: TABLE; Schema: base; Owner: postgres
--

CREATE TABLE base.base_oggetto_categoria (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    parent_id character(22),
    nome text,
    hierarchical_nome text,
    _parent_h_nome text,
    hierarchical_pkey text,
    _parent_h_pkey text,
    _h_count text,
    _parent_h_count text,
    _row_count bigint,
    __ins_user text,
    df_fields text,
    df_fbcolumns bigint,
    df_custom_templates text,
    df_colswidth text,
    descrizione text,
    casa_id character(22),
    posto_id character(22),
    posto_id_def character(22)
);


ALTER TABLE base.base_oggetto_categoria OWNER TO postgres;

--
-- Name: base_posto; Type: TABLE; Schema: base; Owner: postgres
--

CREATE TABLE base.base_posto (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    parent_id character(22),
    nome text,
    hierarchical_nome text,
    _parent_h_nome text,
    hierarchical_pkey text,
    _parent_h_pkey text,
    _h_count text,
    _parent_h_count text,
    _row_count bigint,
    __ins_user text,
    df_fields text,
    df_fbcolumns bigint,
    df_custom_templates text,
    df_colswidth text,
    descrizione text,
    casa_id character(22),
    posto_tipo_id character(22)
);


ALTER TABLE base.base_posto OWNER TO postgres;

--
-- Name: base_posto_tipo; Type: TABLE; Schema: base; Owner: postgres
--

CREATE TABLE base.base_posto_tipo (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    nome text
);


ALTER TABLE base.base_posto_tipo OWNER TO postgres;

--
-- Name: base_utenza; Type: TABLE; Schema: base; Owner: postgres
--

CREATE TABLE base.base_utenza (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    user_id character(22),
    casa_id character(22)
);


ALTER TABLE base.base_utenza OWNER TO postgres;

--
-- Name: sys_batch_log; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_batch_log (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    batch_title text,
    page_id character(22),
    start_ts timestamp without time zone,
    end_ts timestamp without time zone,
    notes text,
    logbag text,
    tbl text
);


ALTER TABLE sys.sys_batch_log OWNER TO postgres;

--
-- Name: sys_dbchange; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_dbchange (
    __ins_ts timestamp without time zone,
    __ins_user text,
    ref bigint NOT NULL,
    tbl character varying(80),
    record_pkey text,
    evt character(1),
    record text,
    dbstore character varying(60)
);


ALTER TABLE sys.sys_dbchange OWNER TO postgres;

--
-- Name: sys_dbchange_ref_seq; Type: SEQUENCE; Schema: sys; Owner: postgres
--

CREATE SEQUENCE sys.sys_dbchange_ref_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sys.sys_dbchange_ref_seq OWNER TO postgres;

--
-- Name: sys_dbchange_ref_seq; Type: SEQUENCE OWNED BY; Schema: sys; Owner: postgres
--

ALTER SEQUENCE sys.sys_dbchange_ref_seq OWNED BY sys.sys_dbchange.ref;


--
-- Name: sys_error; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_error (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    description text,
    error_data text,
    username text,
    user_ip text,
    user_agent text,
    fixed text,
    notes text,
    error_type text
);


ALTER TABLE sys.sys_error OWNER TO postgres;

--
-- Name: sys_external_token; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_external_token (
    id character(22) NOT NULL,
    datetime timestamp without time zone,
    expiry timestamp without time zone,
    allowed_user character varying(32),
    connection_id character(22),
    max_usages integer,
    allowed_host text,
    page_path text,
    method text,
    parameters text,
    exec_user character varying(32)
);


ALTER TABLE sys.sys_external_token OWNER TO postgres;

--
-- Name: sys_external_token_use; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_external_token_use (
    id character(22) NOT NULL,
    external_token_id character(22),
    datetime timestamp without time zone,
    host text
);


ALTER TABLE sys.sys_external_token_use OWNER TO postgres;

--
-- Name: sys_locked_record; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_locked_record (
    id character(22) NOT NULL,
    lock_ts timestamp without time zone,
    lock_table character varying(64),
    lock_pkey character varying(64),
    page_id character(22),
    connection_id character(22),
    username character varying(32)
);


ALTER TABLE sys.sys_locked_record OWNER TO postgres;

--
-- Name: sys_service; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_service (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    service_identifier character varying(60) NOT NULL,
    service_type character varying(30),
    service_name character varying(30),
    implementation text,
    parameters text,
    daemon boolean,
    disabled boolean
);


ALTER TABLE sys.sys_service OWNER TO postgres;

--
-- Name: sys_shared_object; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_shared_object (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    data text,
    backup text,
    description character varying(50),
    linked_table text
);


ALTER TABLE sys.sys_shared_object OWNER TO postgres;

--
-- Name: sys_task; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_task (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    table_name text,
    task_name text,
    command text,
    month text,
    day text,
    weekday text,
    hour text,
    minute text,
    frequency bigint,
    parameters text,
    last_scheduled_ts timestamp without time zone,
    last_execution_ts timestamp without time zone,
    last_error_ts timestamp without time zone,
    last_error_info text,
    run_asap boolean,
    max_workers bigint,
    log_result boolean,
    user_id character(22),
    date_start date,
    date_end date,
    stopped boolean,
    worker_code character varying(10),
    saved_query_code character varying(40)
);


ALTER TABLE sys.sys_task OWNER TO postgres;

--
-- Name: sys_task_execution; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_task_execution (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    task_id character(22),
    result text,
    logbag text,
    errorbag text,
    pid bigint,
    start_ts timestamp without time zone,
    end_ts timestamp without time zone,
    is_error boolean,
    exec_reason character varying(20),
    reasonkey character varying(60)
);


ALTER TABLE sys.sys_task_execution OWNER TO postgres;

--
-- Name: sys_task_result; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_task_result (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    task_id character(22),
    result text,
    result_time timestamp without time zone,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    is_error boolean
);


ALTER TABLE sys.sys_task_result OWNER TO postgres;

--
-- Name: sys_upgrade; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_upgrade (
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    __ins_user text,
    codekey character varying(80) NOT NULL,
    pkg character varying(20),
    filename character varying(40),
    error text
);


ALTER TABLE sys.sys_upgrade OWNER TO postgres;

--
-- Name: sys_widget; Type: TABLE; Schema: sys; Owner: postgres
--

CREATE TABLE sys.sys_widget (
    id character(22) NOT NULL,
    __ins_ts timestamp without time zone,
    __del_ts timestamp without time zone,
    __mod_ts timestamp without time zone,
    parent_id character(22),
    name text,
    hierarchical_name text,
    _parent_h_name text,
    hierarchical_pkey text,
    _parent_h_pkey text,
    __version bigint,
    __ins_user text,
    df_fields text,
    df_fbcolumns bigint,
    df_custom_templates text,
    df_colswidth text,
    summary text,
    server boolean
);


ALTER TABLE sys.sys_widget OWNER TO postgres;

--
-- Name: sys_dbchange ref; Type: DEFAULT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_dbchange ALTER COLUMN ref SET DEFAULT nextval('sys.sys_dbchange_ref_seq'::regclass);


--
-- Data for Name: adm_access_group; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_access_group (__ins_ts, __del_ts, __mod_ts, __ins_user, code, description, allowed_ip) FROM stdin;
\.


--
-- Data for Name: adm_audit; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_audit (id, __ins_ts, __del_ts, __mod_ts, __ins_user, tablename, event, username, record_pkey, version, data, transaction_id) FROM stdin;
\.


--
-- Data for Name: adm_authorization; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_authorization (__ins_ts, __del_ts, __mod_ts, __ins_user, code, user_id, use_ts, used_by, note, usage_scope, remaining_usages, expiry_date) FROM stdin;
\.


--
-- Data for Name: adm_backup; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_backup (id, __ins_ts, __del_ts, __mod_ts, __ins_user, name, start_ts, end_ts) FROM stdin;
cRvomnXnMA6bK5D7uUe2GQ	2020-08-20 12:17:52.158259	\N	2020-08-20 12:17:53.447209	admin	kondo-dump	2020-08-20 12:17:52.157605	2020-08-20 12:17:53.446956
5BIjvw0xNK_Vm2zVU02cGA	2020-08-20 12:22:31.93049	\N	2020-08-20 12:22:32.667499	admin	kondo_dump_plain	2020-08-20 12:22:31.929827	2020-08-20 12:22:32.667303
\.


--
-- Data for Name: adm_ckstyle; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_ckstyle (id, __ins_ts, __del_ts, __mod_ts, __ins_user, name, element, styles, attributes, stylegroup) FROM stdin;
\.


--
-- Data for Name: adm_connection; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_connection (id, userid, username, ip, start_ts, end_ts, end_reason, user_agent) FROM stdin;
\.


--
-- Data for Name: adm_counter; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_counter (__ins_ts, __del_ts, __mod_ts, __ins_user, codekey, code, pkg, tbl, fld, period, counter, last_used, holes, errors) FROM stdin;
\.


--
-- Data for Name: adm_day; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_day (date, weekday, is_holyday) FROM stdin;
\.


--
-- Data for Name: adm_group; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_group (__ins_ts, __del_ts, __mod_ts, _row_count, __ins_user, code, description, custom_menu, rootpage) FROM stdin;
2020-08-20 12:06:02.324531	\N	2020-08-20 12:06:02.324616	2	admin	amm	Amministratore	<?xml version='1.0' encoding='UTF-8'?>\n<GenRoBag><root _T="BAG" label="Root" tag="branch"></root></GenRoBag>	\N
2020-08-20 12:05:39.677419	\N	2020-08-20 14:10:35.227792	1	admin	casalingo	Casalingo	<?xml version='1.0' encoding='UTF-8'?>\n<GenRoBag><root _T="BAG" label="Root" tag="branch"></root></GenRoBag>	/base/gestione_domestica
\.


--
-- Data for Name: adm_htag; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_htag (id, __ins_ts, __del_ts, __mod_ts, parent_id, code, hierarchical_code, _parent_h_code, description, hierarchical_description, _parent_h_description, hierarchical_pkey, _parent_h_pkey, __ins_user, __syscode, isreserved, note) FROM stdin;
_DEV__________________	2020-08-20 12:06:34.755138	\N	2020-08-20 12:06:34.75518	\N	_DEV_	_DEV_	\N	Developer	Developer	\N	_DEV__________________	\N	\N	_DEV_	t	\N
_DOC__________________	2020-08-20 12:06:34.768654	\N	2020-08-20 12:06:34.768688	\N	_DOC_	_DOC_	\N	Documentation	Documentation	\N	_DOC__________________	\N	\N	_DOC_	t	\N
_SYSTEM_______________	2020-08-20 12:06:34.818365	\N	2020-08-20 12:06:34.818401	\N	_SYSTEM_	_SYSTEM_	\N	System	System	\N	_SYSTEM_______________	\N	\N	_SYSTEM_	t	\N
_TRD__________________	2020-08-20 12:06:34.830074	\N	2020-08-20 12:06:34.830109	\N	_TRD_	_TRD_	\N	Translator	Translator	\N	_TRD__________________	\N	\N	_TRD_	t	\N
admin_________________	2020-08-20 12:06:34.878992	\N	2020-08-20 12:06:34.87905	\N	admin	admin	\N	Admin	Admin	\N	admin_________________	\N	\N	admin	\N	\N
superadmin____________	2020-08-20 12:06:34.890987	\N	2020-08-20 12:06:34.891019	\N	superadmin	superadmin	\N	SuperAdmin	SuperAdmin	\N	superadmin____________	\N	\N	superadmin	t	\N
user__________________	2020-08-20 12:06:34.901934	\N	2020-08-20 12:06:34.90197	\N	user	user	\N	User	User	\N	user__________________	\N	\N	user	\N	\N
\.


--
-- Data for Name: adm_htmltemplate; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_htmltemplate (id, __ins_ts, __del_ts, __mod_ts, __ins_user, name, username, version, type_code, data, center_height, center_width, based_on, next_letterhead_id) FROM stdin;
\.


--
-- Data for Name: adm_htmltemplate_atc; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_htmltemplate_atc (id, __del_ts, _row_count, __ins_user, filepath, external_url, description, mimetype, text_content, info, is_foreign_document, maintable_id) FROM stdin;
\.


--
-- Data for Name: adm_install_checklist; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_install_checklist (__del_ts, __ins_user, name, description, pkg, checked, check_ts, check_user, annotations, doc_url) FROM stdin;
\.


--
-- Data for Name: adm_language; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_language (__ins_ts, __del_ts, __mod_ts, _row_count, __ins_user, code, name) FROM stdin;
\.


--
-- Data for Name: adm_letterhead_type; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_letterhead_type (__ins_ts, __del_ts, __mod_ts, __ins_user, code, description) FROM stdin;
\.


--
-- Data for Name: adm_menu; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_menu (id, __ins_ts, __del_ts, __mod_ts, parent_id, label, hierarchical_label, _parent_h_label, hierarchical_pkey, _parent_h_pkey, _h_count, _parent_h_count, _row_count, __ins_user, tags, summary, ts_import, page_id) FROM stdin;
\.


--
-- Data for Name: adm_menu_page; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_menu_page (id, __ins_ts, __del_ts, __mod_ts, __ins_user, label, filepath, tbl, pkg, metadata) FROM stdin;
\.


--
-- Data for Name: adm_notification; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_notification (id, __ins_ts, __del_ts, __mod_ts, __ins_user, title, template, confirm_label, tag_rule, all_users, letterhead_id) FROM stdin;
\.


--
-- Data for Name: adm_pkginfo; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_pkginfo (__ins_ts, __del_ts, __mod_ts, __ins_user, pkgid, prj) FROM stdin;
2020-08-20 14:13:43.692216	\N	2020-08-20 14:13:43.692288	\N	sys	\N
2020-08-20 14:13:43.711173	\N	2020-08-20 14:13:43.711194	\N	adm	\N
2020-08-20 14:13:43.736535	\N	2020-08-20 14:13:43.736556	\N	base	\N
\.


--
-- Data for Name: adm_preference; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_preference (__ins_ts, __del_ts, __mod_ts, __ins_user, code, data) FROM stdin;
2020-08-20 11:25:25.703601	\N	2020-08-20 11:25:25.703651	\N	_mainpref_  	\N
\.


--
-- Data for Name: adm_record_tag; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_record_tag (id, __ins_ts, __del_ts, __mod_ts, __ins_user, tablename, tag, description) FROM stdin;
\.


--
-- Data for Name: adm_sent_email; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_sent_email (id, __ins_ts, __del_ts, __mod_ts, __ins_user, code, tbl, mail_address, sent_ts, record_id) FROM stdin;
\.


--
-- Data for Name: adm_served_page; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_served_page (page_id, pagename, connection_id, start_ts, end_ts, end_reason) FROM stdin;
\.


--
-- Data for Name: adm_shortcut; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_shortcut (__ins_ts, __del_ts, __mod_ts, _row_count, __ins_user, keycode, phrase, groupcode) FROM stdin;
\.


--
-- Data for Name: adm_tblinfo; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_tblinfo (__ins_ts, __del_ts, __mod_ts, __ins_user, tblid, pkgid, description) FROM stdin;
2020-08-20 14:13:43.695051	\N	2020-08-20 14:13:43.695099	\N	sys.batch_log	sys	\N
2020-08-20 14:13:43.698498	\N	2020-08-20 14:13:43.698528	\N	sys.dbchange	sys	\N
2020-08-20 14:13:43.699468	\N	2020-08-20 14:13:43.699489	\N	sys.error	sys	\N
2020-08-20 14:13:43.700173	\N	2020-08-20 14:13:43.700197	\N	sys.external_token	sys	\N
2020-08-20 14:13:43.701328	\N	2020-08-20 14:13:43.70136	\N	sys.external_token_use	sys	\N
2020-08-20 14:13:43.702297	\N	2020-08-20 14:13:43.702321	\N	sys.locked_record	sys	\N
2020-08-20 14:13:43.703041	\N	2020-08-20 14:13:43.703061	\N	sys.service	sys	\N
2020-08-20 14:13:43.703739	\N	2020-08-20 14:13:43.70376	\N	sys.shared_object	sys	\N
2020-08-20 14:13:43.704492	\N	2020-08-20 14:13:43.704513	\N	sys.task	sys	\N
2020-08-20 14:13:43.705354	\N	2020-08-20 14:13:43.705392	\N	sys.task_execution	sys	\N
2020-08-20 14:13:43.706959	\N	2020-08-20 14:13:43.706989	\N	sys.task_result	sys	\N
2020-08-20 14:13:43.708326	\N	2020-08-20 14:13:43.708469	\N	sys.upgrade	sys	\N
2020-08-20 14:13:43.71046	\N	2020-08-20 14:13:43.710485	\N	sys.widget	sys	\N
2020-08-20 14:13:43.712195	\N	2020-08-20 14:13:43.71222	\N	adm.access_group	adm	\N
2020-08-20 14:13:43.712998	\N	2020-08-20 14:13:43.713021	\N	adm.audit	adm	\N
2020-08-20 14:13:43.713821	\N	2020-08-20 14:13:43.713842	\N	adm.authorization	adm	\N
2020-08-20 14:13:43.714541	\N	2020-08-20 14:13:43.714563	\N	adm.backup	adm	\N
2020-08-20 14:13:43.715261	\N	2020-08-20 14:13:43.715295	\N	adm.ckstyle	adm	\N
2020-08-20 14:13:43.716115	\N	2020-08-20 14:13:43.716137	\N	adm.connection	adm	\N
2020-08-20 14:13:43.717211	\N	2020-08-20 14:13:43.717237	\N	adm.counter	adm	\N
2020-08-20 14:13:43.718163	\N	2020-08-20 14:13:43.718184	\N	adm.day	adm	\N
2020-08-20 14:13:43.718843	\N	2020-08-20 14:13:43.718863	\N	adm.group	adm	\N
2020-08-20 14:13:43.719496	\N	2020-08-20 14:13:43.719516	\N	adm.htag	adm	\N
2020-08-20 14:13:43.72019	\N	2020-08-20 14:13:43.720209	\N	adm.htmltemplate	adm	\N
2020-08-20 14:13:43.720869	\N	2020-08-20 14:13:43.720889	\N	adm.htmltemplate_atc	adm	\N
2020-08-20 14:13:43.72152	\N	2020-08-20 14:13:43.721539	\N	adm.install_checklist	adm	\N
2020-08-20 14:13:43.722411	\N	2020-08-20 14:13:43.722434	\N	adm.language	adm	\N
2020-08-20 14:13:43.723193	\N	2020-08-20 14:13:43.723217	\N	adm.letterhead_type	adm	\N
2020-08-20 14:13:43.724238	\N	2020-08-20 14:13:43.72427	\N	adm.menu	adm	\N
2020-08-20 14:13:43.7254	\N	2020-08-20 14:13:43.725423	\N	adm.menu_page	adm	\N
2020-08-20 14:13:43.726146	\N	2020-08-20 14:13:43.726169	\N	adm.notification	adm	\N
2020-08-20 14:13:43.726781	\N	2020-08-20 14:13:43.726802	\N	adm.pkginfo	adm	\N
2020-08-20 14:13:43.727406	\N	2020-08-20 14:13:43.727428	\N	adm.preference	adm	\N
2020-08-20 14:13:43.728026	\N	2020-08-20 14:13:43.728047	\N	adm.record_tag	adm	\N
2020-08-20 14:13:43.728639	\N	2020-08-20 14:13:43.72866	\N	adm.sent_email	adm	\N
2020-08-20 14:13:43.729251	\N	2020-08-20 14:13:43.729272	\N	adm.served_page	adm	\N
2020-08-20 14:13:43.729926	\N	2020-08-20 14:13:43.729945	\N	adm.shortcut	adm	\N
2020-08-20 14:13:43.73063	\N	2020-08-20 14:13:43.73065	\N	adm.tblinfo	adm	\N
2020-08-20 14:13:43.731314	\N	2020-08-20 14:13:43.731333	\N	adm.tblinfo_item	adm	\N
2020-08-20 14:13:43.732086	\N	2020-08-20 14:13:43.732152	\N	adm.user	adm	\N
2020-08-20 14:13:43.733076	\N	2020-08-20 14:13:43.733099	\N	adm.user_access_group	adm	\N
2020-08-20 14:13:43.733757	\N	2020-08-20 14:13:43.733778	\N	adm.user_config	adm	\N
2020-08-20 14:13:43.734431	\N	2020-08-20 14:13:43.734452	\N	adm.user_notification	adm	\N
2020-08-20 14:13:43.735236	\N	2020-08-20 14:13:43.735257	\N	adm.user_tag	adm	\N
2020-08-20 14:13:43.735907	\N	2020-08-20 14:13:43.735929	\N	adm.userobject	adm	\N
2020-08-20 14:13:43.737143	\N	2020-08-20 14:13:43.737163	\N	base.casa	base	\N
2020-08-20 14:13:43.737765	\N	2020-08-20 14:13:43.737786	\N	base.oggetto	base	\N
2020-08-20 14:13:43.738385	\N	2020-08-20 14:13:43.738405	\N	base.oggetto_categoria	base	\N
2020-08-20 14:13:43.739226	\N	2020-08-20 14:13:43.739248	\N	base.posto	base	\N
2020-08-20 14:13:43.740207	\N	2020-08-20 14:13:43.740313	\N	base.utenza	base	\N
2020-08-20 14:29:15.571491	\N	2020-08-20 14:29:15.571517	\N	base.posto_tipo	base	\N
\.


--
-- Data for Name: adm_tblinfo_item; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_tblinfo_item (__ins_ts, __del_ts, __mod_ts, __ins_user, info_key, code, description, item_type, data, tblid) FROM stdin;
\.


--
-- Data for Name: adm_user; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_user (id, __ins_ts, __del_ts, __mod_ts, __rec_md5, __ins_user, username, email, mobile, firstname, lastname, registration_date, auth_tags, status, md5pwd, locale, preferences, menu_root_id, avatar_rootpage, sms_login, sms_number, group_code, custom_menu) FROM stdin;
4yC8TCRaOyC8aFCdeOiRgQ	2020-08-20 11:28:14.566567	\N	2020-08-20 12:05:48.647305	\N	admin	carla	carla@softwell.it	\N	Carla	Tegami	\N	\N	conf	1fa4a2211b4e290f2a066de6b84187ec	\N	\N	\N	\N	\N	\N	casalingo	\N
v8tZgfJKODG_SJPpb3A8_w	2020-08-20 11:27:49.852637	\N	2020-08-20 12:05:48.664312	\N	admin	ghigo	francesco.porcari@softwell.it	\N	Ghigo	Porcari	\N	\N	conf	b1a391acdfd9c2cbcf0ebf4daea22a1a	\N	\N	\N	\N	\N	\N	casalingo	\N
uZAqvfN_NjK6R7V1VqAjVQ	2020-08-20 11:27:26.058506	\N	2020-08-20 12:05:48.684799	\N	admin	dpaci	davide.paci@softwell.it	\N	Davide	Paci	\N	\N	conf	d1927e7e4c65b2c97c6ec18c39bbf54b	\N	\N	\N	\N	\N	\N	casalingo	\N
r56_wdXgOKa_rxDOWu0cpQ	2020-08-20 11:27:02.188421	\N	2020-08-20 12:05:48.70886	\N	admin	stefania	stenki@live.it	\N	Stefania	Paci	\N	\N	conf	3b057c42b301ee27cfe3371aecd4ce26	\N	\N	\N	\N	\N	\N	casalingo	\N
\.


--
-- Data for Name: adm_user_access_group; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_user_access_group (id, __ins_ts, __del_ts, __mod_ts, __ins_user, user_id, access_group_code) FROM stdin;
\.


--
-- Data for Name: adm_user_config; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_user_config (__ins_ts, __del_ts, __mod_ts, __ins_user, ruleid, user_group, username, pkgid, tblid, data) FROM stdin;
\.


--
-- Data for Name: adm_user_notification; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_user_notification (id, __ins_ts, __del_ts, __mod_ts, __ins_user, user_id, notification_id, confirmed) FROM stdin;
\.


--
-- Data for Name: adm_user_tag; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_user_tag (id, __ins_ts, __del_ts, __mod_ts, __ins_user, group_code, user_id, tag_id) FROM stdin;
TqD6TEztMjCkrUQoX6wOlQ	2020-08-20 12:07:27.815176	\N	2020-08-20 12:07:27.815274	admin	amm	\N	_DEV__________________
bem3mwUYOEWT3_PuwZMI5A	2020-08-20 12:07:27.837442	\N	2020-08-20 12:07:27.837504	admin	amm	\N	_DOC__________________
OP0tPTsTMPq5btZgnmacnw	2020-08-20 12:07:27.839288	\N	2020-08-20 12:07:27.839329	admin	amm	\N	_SYSTEM_______________
gvLw0_QyMwO4kSENWOPnhQ	2020-08-20 12:07:27.879414	\N	2020-08-20 12:07:27.879483	admin	amm	\N	_TRD__________________
vE9r7I1_Om_ZBYr3uDiReg	2020-08-20 12:07:27.885956	\N	2020-08-20 12:07:27.886018	admin	amm	\N	admin_________________
OvrFwcbgOOW0heqstfds1Q	2020-08-20 12:07:27.889965	\N	2020-08-20 12:07:27.890005	admin	amm	\N	superadmin____________
gf24YO08M5KuHGaeyGhxDw	2020-08-20 12:07:27.891201	\N	2020-08-20 12:07:27.891238	admin	amm	\N	user__________________
Rxo69r4aNt6j9YnLY4JEHQ	2020-08-20 12:07:40.449906	\N	2020-08-20 12:07:40.449988	admin	casalingo	\N	user__________________
\.


--
-- Data for Name: adm_userobject; Type: TABLE DATA; Schema: adm; Owner: postgres
--

COPY adm.adm_userobject (id, __ins_ts, __del_ts, __mod_ts, __ins_user, identifier, code, objtype, pkg, tbl, userid, description, notes, data, authtags, private, quicklist, flags, required_pkg, preview) FROM stdin;
\.


--
-- Data for Name: base_casa; Type: TABLE DATA; Schema: base; Owner: postgres
--

COPY base.base_casa (id, __ins_ts, __del_ts, __mod_ts, __ins_user, nome, descrizione) FROM stdin;
R_xrRfMWP4u4f92SCZXINA	2020-08-20 11:28:34.237674	\N	2020-08-20 11:28:34.237711	admin	Casa Paci	Appartamento via Valera Arese
dswI_bkoORyGwBR78YyrMQ	2020-08-20 11:29:21.601387	\N	2020-08-20 11:29:21.601427	admin	Porcadossi	Casa Ghigo Abbiategrasso
CgEEmC8NMNGvUE2_tfqUXQ	2020-08-20 11:29:52.728561	\N	2020-08-20 11:29:52.728602	admin	Porgami	Casa Porcari-Tegami
\.


--
-- Data for Name: base_locazione; Type: TABLE DATA; Schema: base; Owner: postgres
--

COPY base.base_locazione (id, __ins_ts, __del_ts, __mod_ts, parent_id, nome, hierarchical_nome, _parent_h_nome, hierarchical_pkey, _parent_h_pkey, _h_count, _parent_h_count, _row_count, __ins_user, df_fields, df_fbcolumns, df_custom_templates, df_colswidth, descrizione, casa_id) FROM stdin;
\.


--
-- Data for Name: base_oggetto; Type: TABLE DATA; Schema: base; Owner: postgres
--

COPY base.base_oggetto (id, __ins_ts, __del_ts, __mod_ts, __ins_user, nome, anno_acquisto, foto, locazione_id, categoria_id, casa_id, posto_id, quantita) FROM stdin;
CuS9XC_MORmc01hAz1teqw	2020-08-20 16:20:38.332181	\N	2020-08-20 16:20:38.332219	admin	Quadro Segantini	1915	\N	\N	PREGOi1JNgOTAlA4LjbcKg	\N	nz49Z4yTPguiTTARj4KWaA	1
\.


--
-- Data for Name: base_oggetto_categoria; Type: TABLE DATA; Schema: base; Owner: postgres
--

COPY base.base_oggetto_categoria (id, __ins_ts, __del_ts, __mod_ts, parent_id, nome, hierarchical_nome, _parent_h_nome, hierarchical_pkey, _parent_h_pkey, _h_count, _parent_h_count, _row_count, __ins_user, df_fields, df_fbcolumns, df_custom_templates, df_colswidth, descrizione, casa_id, posto_id, posto_id_def) FROM stdin;
PREGOi1JNgOTAlA4LjbcKg	2020-08-20 15:23:57.752779	\N	2020-08-20 15:24:05.821982	\N	Quadri	Quadri	\N	PREGOi1JNgOTAlA4LjbcKg	\N	01	\N	1	admin	\N	\N	\N	\N	\N	\N	\N	nz49Z4yTPguiTTARj4KWaA
wnjW6fzqPyeHiBtfzAqRYw	2020-08-20 15:24:26.979523	\N	2020-08-20 15:24:26.979561	\N	Elettrodomestici	Elettrodomestici	\N	wnjW6fzqPyeHiBtfzAqRYw	\N	02	\N	2	admin	\N	\N	\N	\N	\N	\N	\N	bF5l1hurPdmB_Cq6u0aaeg
\.


--
-- Data for Name: base_posto; Type: TABLE DATA; Schema: base; Owner: postgres
--

COPY base.base_posto (id, __ins_ts, __del_ts, __mod_ts, parent_id, nome, hierarchical_nome, _parent_h_nome, hierarchical_pkey, _parent_h_pkey, _h_count, _parent_h_count, _row_count, __ins_user, df_fields, df_fbcolumns, df_custom_templates, df_colswidth, descrizione, casa_id, posto_tipo_id) FROM stdin;
5LuCQNE7Oj6Slh4yPVotGg	2020-08-20 15:19:31.222155	\N	2020-08-20 15:19:38.837206	\N	Stanze	Stanze	\N	5LuCQNE7Oj6Slh4yPVotGg	\N	01	\N	1	admin	\N	\N	\N	\N	\N	\N	\N
nz49Z4yTPguiTTARj4KWaA	2020-08-20 15:19:00.553178	\N	2020-08-20 15:19:40.950256	5LuCQNE7Oj6Slh4yPVotGg	Soggiorno	Stanze/Soggiorno	Stanze	5LuCQNE7Oj6Slh4yPVotGg/nz49Z4yTPguiTTARj4KWaA	5LuCQNE7Oj6Slh4yPVotGg	0101	01	1	admin	\N	\N	\N	\N	Soggiorno	\N	\N
_33ewuOXN_OxjRc1F98zuw	2020-08-20 15:19:21.512885	\N	2020-08-20 15:19:42.461241	5LuCQNE7Oj6Slh4yPVotGg	Cantina	Stanze/Cantina	Stanze	5LuCQNE7Oj6Slh4yPVotGg/_33ewuOXN_OxjRc1F98zuw	5LuCQNE7Oj6Slh4yPVotGg	0102	01	2	admin	\N	\N	\N	\N	\N	\N	\N
XgoJphC2MJqhVJbaLeWdAQ	2020-08-20 15:20:51.488996	\N	2020-08-20 15:20:51.489075	5LuCQNE7Oj6Slh4yPVotGg	Camera da Letto	Stanze/Camera da Letto	Stanze	5LuCQNE7Oj6Slh4yPVotGg/XgoJphC2MJqhVJbaLeWdAQ	5LuCQNE7Oj6Slh4yPVotGg	0103	01	3	admin	\N	\N	\N	\N	\N	\N	\N
u8jfASt4OeCYnwYZao0VSA	2020-08-20 15:21:02.297534	\N	2020-08-20 15:21:02.297612	5LuCQNE7Oj6Slh4yPVotGg	Bagno	Stanze/Bagno	Stanze	5LuCQNE7Oj6Slh4yPVotGg/u8jfASt4OeCYnwYZao0VSA	5LuCQNE7Oj6Slh4yPVotGg	0104	01	4	admin	\N	\N	\N	\N	\N	\N	\N
tI2sHeieNXeR01fml7HmbQ	2020-08-20 15:21:22.631559	\N	2020-08-20 15:21:22.631602	\N	Mobili	Mobili	\N	tI2sHeieNXeR01fml7HmbQ	\N	02	\N	2	admin	\N	\N	\N	\N	\N	\N	\N
VgKvf83kOSOQnqjwD__RAw	2020-08-20 15:21:29.031695	\N	2020-08-20 15:21:43.77998	tI2sHeieNXeR01fml7HmbQ	Armadio	Mobili/Armadio	Mobili	tI2sHeieNXeR01fml7HmbQ/VgKvf83kOSOQnqjwD__RAw	tI2sHeieNXeR01fml7HmbQ	0203	02	3	admin	\N	\N	\N	\N	\N	\N	\N
a_ZMwOg_PEmWLrUxlyfVRQ	2020-08-20 15:21:37.802009	\N	2020-08-20 15:21:45.505749	tI2sHeieNXeR01fml7HmbQ	Letto contenitore	Mobili/Letto contenitore	Mobili	tI2sHeieNXeR01fml7HmbQ/a_ZMwOg_PEmWLrUxlyfVRQ	tI2sHeieNXeR01fml7HmbQ	0204	02	4	admin	\N	\N	\N	\N	\N	\N	\N
22KY9NCYNZ6KZDdyNMBsAA	2020-08-20 15:21:52.645006	\N	2020-08-20 15:21:52.645048	5LuCQNE7Oj6Slh4yPVotGg	Ripostiglio	Stanze/Ripostiglio	Stanze	5LuCQNE7Oj6Slh4yPVotGg/22KY9NCYNZ6KZDdyNMBsAA	5LuCQNE7Oj6Slh4yPVotGg	0105	01	5	admin	\N	\N	\N	\N	\N	\N	\N
bF5l1hurPdmB_Cq6u0aaeg	2020-08-20 15:22:10.747177	\N	2020-08-20 15:22:10.747227	5LuCQNE7Oj6Slh4yPVotGg	Cucina	Stanze/Cucina	Stanze	5LuCQNE7Oj6Slh4yPVotGg/bF5l1hurPdmB_Cq6u0aaeg	5LuCQNE7Oj6Slh4yPVotGg	0106	01	6	admin	\N	\N	\N	\N	\N	\N	\N
TD7N2yZrPk2eYishuXwWqA	2020-08-20 15:22:16.90383	\N	2020-08-20 15:22:16.903875	tI2sHeieNXeR01fml7HmbQ	Cucina	Mobili/Cucina	Mobili	tI2sHeieNXeR01fml7HmbQ/TD7N2yZrPk2eYishuXwWqA	tI2sHeieNXeR01fml7HmbQ	0205	02	5	admin	\N	\N	\N	\N	\N	\N	\N
RcbsH8PlMBqHlOaY3QNbOQ	2020-08-20 15:22:37.608671	\N	2020-08-20 15:22:37.608714	5LuCQNE7Oj6Slh4yPVotGg	Corridoio	Stanze/Corridoio	Stanze	5LuCQNE7Oj6Slh4yPVotGg/RcbsH8PlMBqHlOaY3QNbOQ	5LuCQNE7Oj6Slh4yPVotGg	0107	01	7	admin	\N	\N	\N	\N	\N	\N	\N
3MFLciKdPrGVhAAZz8p_Ww	2020-08-20 15:23:09.562701	\N	2020-08-20 15:23:09.562745	tI2sHeieNXeR01fml7HmbQ	Mensola	Mobili/Mensola	Mobili	tI2sHeieNXeR01fml7HmbQ/3MFLciKdPrGVhAAZz8p_Ww	tI2sHeieNXeR01fml7HmbQ	0206	02	6	admin	\N	\N	\N	\N	\N	\N	\N
XUT2qBxfNC6mplMtLaVvLg	2020-08-20 15:23:16.296918	\N	2020-08-20 15:23:16.296961	VgKvf83kOSOQnqjwD__RAw	Anta	Mobili/Armadio/Anta	Mobili/Armadio	tI2sHeieNXeR01fml7HmbQ/VgKvf83kOSOQnqjwD__RAw/XUT2qBxfNC6mplMtLaVvLg	tI2sHeieNXeR01fml7HmbQ/VgKvf83kOSOQnqjwD__RAw	020301	0203	1	admin	\N	\N	\N	\N	\N	\N	\N
RptbqRajMYaCfK5R_tgfFQ	2020-08-20 15:23:26.763341	\N	2020-08-20 15:23:29.724889	VgKvf83kOSOQnqjwD__RAw	Cassetto	Mobili/Armadio/Cassetto	Mobili/Armadio	tI2sHeieNXeR01fml7HmbQ/VgKvf83kOSOQnqjwD__RAw/RptbqRajMYaCfK5R_tgfFQ	tI2sHeieNXeR01fml7HmbQ/VgKvf83kOSOQnqjwD__RAw	020301	0203	1	admin	\N	\N	\N	\N	\N	\N	\N
kK0mhfW0MQenrvm8zaSn_Q	2020-08-20 15:23:41.383955	\N	2020-08-20 15:23:41.383998	TD7N2yZrPk2eYishuXwWqA	Cassetto	Mobili/Cucina/Cassetto	Mobili/Cucina	tI2sHeieNXeR01fml7HmbQ/TD7N2yZrPk2eYishuXwWqA/kK0mhfW0MQenrvm8zaSn_Q	tI2sHeieNXeR01fml7HmbQ/TD7N2yZrPk2eYishuXwWqA	020501	0205	1	admin	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: base_posto_tipo; Type: TABLE DATA; Schema: base; Owner: postgres
--

COPY base.base_posto_tipo (id, __ins_ts, __del_ts, __mod_ts, __ins_user, nome) FROM stdin;
QeoEtXAuO7O3vTppG454OA	2020-08-20 14:52:45.551559	\N	2020-08-20 14:52:45.551643	admin	Armadio
pAImMb6mPUiFtFupAudLIQ	2020-08-20 14:52:45.731024	\N	2020-08-20 14:52:45.731076	admin	Scaffale
NlVk2_IlMoGEHseyZ01kUA	2020-08-20 15:08:06.453596	\N	2020-08-20 15:08:06.453675	admin	Corridoio
KZZvjfd6OQi_qy3gsKYEvQ	2020-08-20 15:08:06.464164	\N	2020-08-20 15:08:06.464215	admin	Stanza
\.


--
-- Data for Name: base_utenza; Type: TABLE DATA; Schema: base; Owner: postgres
--

COPY base.base_utenza (id, __ins_ts, __del_ts, __mod_ts, __ins_user, user_id, casa_id) FROM stdin;
46cjgvQrMkCjhzdrktJ9_A	2020-08-20 11:28:43.541638	\N	2020-08-20 11:28:43.54169	admin	uZAqvfN_NjK6R7V1VqAjVQ	R_xrRfMWP4u4f92SCZXINA
6_dCOreeORmiJs_IKX7kBQ	2020-08-20 11:28:43.553856	\N	2020-08-20 11:28:43.553885	admin	r56_wdXgOKa_rxDOWu0cpQ	R_xrRfMWP4u4f92SCZXINA
LoB9n1N9OFCJ_qV4Ay6eyw	2020-08-20 11:29:26.035201	\N	2020-08-20 11:29:26.035257	admin	v8tZgfJKODG_SJPpb3A8_w	dswI_bkoORyGwBR78YyrMQ
hueoLW6WOheK70locDpoJw	2020-08-20 11:29:57.560084	\N	2020-08-20 11:29:57.560134	admin	4yC8TCRaOyC8aFCdeOiRgQ	CgEEmC8NMNGvUE2_tfqUXQ
emHSsJp9Og6iU07Q2jj6Ew	2020-08-20 11:29:57.573085	\N	2020-08-20 11:29:57.573114	admin	v8tZgfJKODG_SJPpb3A8_w	CgEEmC8NMNGvUE2_tfqUXQ
\.


--
-- Data for Name: sys_batch_log; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_batch_log (id, __ins_ts, __del_ts, __mod_ts, __ins_user, batch_title, page_id, start_ts, end_ts, notes, logbag, tbl) FROM stdin;
\.


--
-- Data for Name: sys_dbchange; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_dbchange (__ins_ts, __ins_user, ref, tbl, record_pkey, evt, record, dbstore) FROM stdin;
\.


--
-- Data for Name: sys_error; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_error (id, __ins_ts, __del_ts, __mod_ts, __ins_user, description, error_data, username, user_ip, user_agent, fixed, notes, error_type) FROM stdin;
\.


--
-- Data for Name: sys_external_token; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_external_token (id, datetime, expiry, allowed_user, connection_id, max_usages, allowed_host, page_path, method, parameters, exec_user) FROM stdin;
\.


--
-- Data for Name: sys_external_token_use; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_external_token_use (id, external_token_id, datetime, host) FROM stdin;
\.


--
-- Data for Name: sys_locked_record; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_locked_record (id, lock_ts, lock_table, lock_pkey, page_id, connection_id, username) FROM stdin;
\.


--
-- Data for Name: sys_service; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_service (__ins_ts, __del_ts, __mod_ts, __ins_user, service_identifier, service_type, service_name, implementation, parameters, daemon, disabled) FROM stdin;
\.


--
-- Data for Name: sys_shared_object; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_shared_object (id, __ins_ts, __del_ts, __mod_ts, __ins_user, data, backup, description, linked_table) FROM stdin;
\.


--
-- Data for Name: sys_task; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_task (id, __ins_ts, __del_ts, __mod_ts, __ins_user, table_name, task_name, command, month, day, weekday, hour, minute, frequency, parameters, last_scheduled_ts, last_execution_ts, last_error_ts, last_error_info, run_asap, max_workers, log_result, user_id, date_start, date_end, stopped, worker_code, saved_query_code) FROM stdin;
\.


--
-- Data for Name: sys_task_execution; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_task_execution (id, __ins_ts, __del_ts, __mod_ts, __ins_user, task_id, result, logbag, errorbag, pid, start_ts, end_ts, is_error, exec_reason, reasonkey) FROM stdin;
\.


--
-- Data for Name: sys_task_result; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_task_result (id, __ins_ts, __del_ts, __mod_ts, __ins_user, task_id, result, result_time, start_time, end_time, is_error) FROM stdin;
\.


--
-- Data for Name: sys_upgrade; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_upgrade (__ins_ts, __del_ts, __mod_ts, __ins_user, codekey, pkg, filename, error) FROM stdin;
2020-08-20 12:06:35.007982	\N	2020-08-20 12:06:35.008041	\N	adm|0001_userobject_identifier	adm	0001_userobject_identifier	\N
2020-08-20 12:06:35.023405	\N	2020-08-20 12:06:35.023443	\N	adm|0002_move_pref_mail_account	adm	0002_move_pref_mail_account	\N
\.


--
-- Data for Name: sys_widget; Type: TABLE DATA; Schema: sys; Owner: postgres
--

COPY sys.sys_widget (id, __ins_ts, __del_ts, __mod_ts, parent_id, name, hierarchical_name, _parent_h_name, hierarchical_pkey, _parent_h_pkey, __version, __ins_user, df_fields, df_fbcolumns, df_custom_templates, df_colswidth, summary, server) FROM stdin;
\.


--
-- Name: sys_dbchange_ref_seq; Type: SEQUENCE SET; Schema: sys; Owner: postgres
--

SELECT pg_catalog.setval('sys.sys_dbchange_ref_seq', 1, false);


--
-- Name: adm_access_group adm_access_group_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_access_group
    ADD CONSTRAINT adm_access_group_pkey PRIMARY KEY (code);


--
-- Name: adm_audit adm_audit_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_audit
    ADD CONSTRAINT adm_audit_pkey PRIMARY KEY (id);


--
-- Name: adm_authorization adm_authorization_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_authorization
    ADD CONSTRAINT adm_authorization_pkey PRIMARY KEY (code);


--
-- Name: adm_backup adm_backup_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_backup
    ADD CONSTRAINT adm_backup_pkey PRIMARY KEY (id);


--
-- Name: adm_ckstyle adm_ckstyle_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_ckstyle
    ADD CONSTRAINT adm_ckstyle_pkey PRIMARY KEY (id);


--
-- Name: adm_connection adm_connection_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_connection
    ADD CONSTRAINT adm_connection_pkey PRIMARY KEY (id);


--
-- Name: adm_counter adm_counter_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_counter
    ADD CONSTRAINT adm_counter_pkey PRIMARY KEY (codekey);


--
-- Name: adm_day adm_day_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_day
    ADD CONSTRAINT adm_day_pkey PRIMARY KEY (date);


--
-- Name: adm_group adm_group_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_group
    ADD CONSTRAINT adm_group_pkey PRIMARY KEY (code);


--
-- Name: adm_htag adm_htag___syscode_key; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htag
    ADD CONSTRAINT adm_htag___syscode_key UNIQUE (__syscode);


--
-- Name: adm_htag adm_htag_hierarchical_code_key; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htag
    ADD CONSTRAINT adm_htag_hierarchical_code_key UNIQUE (hierarchical_code);


--
-- Name: adm_htag adm_htag_hierarchical_pkey_key; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htag
    ADD CONSTRAINT adm_htag_hierarchical_pkey_key UNIQUE (hierarchical_pkey);


--
-- Name: adm_htag adm_htag_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htag
    ADD CONSTRAINT adm_htag_pkey PRIMARY KEY (id);


--
-- Name: adm_htmltemplate_atc adm_htmltemplate_atc_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htmltemplate_atc
    ADD CONSTRAINT adm_htmltemplate_atc_pkey PRIMARY KEY (id);


--
-- Name: adm_htmltemplate adm_htmltemplate_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htmltemplate
    ADD CONSTRAINT adm_htmltemplate_pkey PRIMARY KEY (id);


--
-- Name: adm_language adm_language_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_language
    ADD CONSTRAINT adm_language_pkey PRIMARY KEY (code);


--
-- Name: adm_letterhead_type adm_letterhead_type_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_letterhead_type
    ADD CONSTRAINT adm_letterhead_type_pkey PRIMARY KEY (code);


--
-- Name: adm_menu adm_menu_hierarchical_pkey_key; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_menu
    ADD CONSTRAINT adm_menu_hierarchical_pkey_key UNIQUE (hierarchical_pkey);


--
-- Name: adm_menu_page adm_menu_page_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_menu_page
    ADD CONSTRAINT adm_menu_page_pkey PRIMARY KEY (id);


--
-- Name: adm_menu adm_menu_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_menu
    ADD CONSTRAINT adm_menu_pkey PRIMARY KEY (id);


--
-- Name: adm_notification adm_notification_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_notification
    ADD CONSTRAINT adm_notification_pkey PRIMARY KEY (id);


--
-- Name: adm_pkginfo adm_pkginfo_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_pkginfo
    ADD CONSTRAINT adm_pkginfo_pkey PRIMARY KEY (pkgid);


--
-- Name: adm_preference adm_preference_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_preference
    ADD CONSTRAINT adm_preference_pkey PRIMARY KEY (code);


--
-- Name: adm_record_tag adm_record_tag_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_record_tag
    ADD CONSTRAINT adm_record_tag_pkey PRIMARY KEY (id);


--
-- Name: adm_sent_email adm_sent_email_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_sent_email
    ADD CONSTRAINT adm_sent_email_pkey PRIMARY KEY (id);


--
-- Name: adm_served_page adm_served_page_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_served_page
    ADD CONSTRAINT adm_served_page_pkey PRIMARY KEY (page_id);


--
-- Name: adm_shortcut adm_shortcut_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_shortcut
    ADD CONSTRAINT adm_shortcut_pkey PRIMARY KEY (keycode);


--
-- Name: adm_tblinfo_item adm_tblinfo_item_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_tblinfo_item
    ADD CONSTRAINT adm_tblinfo_item_pkey PRIMARY KEY (info_key);


--
-- Name: adm_tblinfo adm_tblinfo_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_tblinfo
    ADD CONSTRAINT adm_tblinfo_pkey PRIMARY KEY (tblid);


--
-- Name: adm_user_access_group adm_user_access_group_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_access_group
    ADD CONSTRAINT adm_user_access_group_pkey PRIMARY KEY (id);


--
-- Name: adm_user_config adm_user_config_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_config
    ADD CONSTRAINT adm_user_config_pkey PRIMARY KEY (ruleid);


--
-- Name: adm_user_notification adm_user_notification_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_notification
    ADD CONSTRAINT adm_user_notification_pkey PRIMARY KEY (id);


--
-- Name: adm_user adm_user_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user
    ADD CONSTRAINT adm_user_pkey PRIMARY KEY (id);


--
-- Name: adm_user_tag adm_user_tag_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_tag
    ADD CONSTRAINT adm_user_tag_pkey PRIMARY KEY (id);


--
-- Name: adm_user adm_user_username_key; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user
    ADD CONSTRAINT adm_user_username_key UNIQUE (username);


--
-- Name: adm_userobject adm_userobject_identifier_key; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_userobject
    ADD CONSTRAINT adm_userobject_identifier_key UNIQUE (identifier);


--
-- Name: adm_userobject adm_userobject_pkey; Type: CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_userobject
    ADD CONSTRAINT adm_userobject_pkey PRIMARY KEY (id);


--
-- Name: base_casa base_casa_pkey; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_casa
    ADD CONSTRAINT base_casa_pkey PRIMARY KEY (id);


--
-- Name: base_locazione base_locazione_hierarchical_pkey_key; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_locazione
    ADD CONSTRAINT base_locazione_hierarchical_pkey_key UNIQUE (hierarchical_pkey);


--
-- Name: base_locazione base_locazione_pkey; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_locazione
    ADD CONSTRAINT base_locazione_pkey PRIMARY KEY (id);


--
-- Name: base_oggetto_categoria base_oggetto_categoria_hierarchical_pkey_key; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto_categoria
    ADD CONSTRAINT base_oggetto_categoria_hierarchical_pkey_key UNIQUE (hierarchical_pkey);


--
-- Name: base_oggetto_categoria base_oggetto_categoria_pkey; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto_categoria
    ADD CONSTRAINT base_oggetto_categoria_pkey PRIMARY KEY (id);


--
-- Name: base_oggetto base_oggetto_pkey; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto
    ADD CONSTRAINT base_oggetto_pkey PRIMARY KEY (id);


--
-- Name: base_posto base_posto_hierarchical_pkey_key; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_posto
    ADD CONSTRAINT base_posto_hierarchical_pkey_key UNIQUE (hierarchical_pkey);


--
-- Name: base_posto base_posto_pkey; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_posto
    ADD CONSTRAINT base_posto_pkey PRIMARY KEY (id);


--
-- Name: base_posto_tipo base_posto_tipo_pkey; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_posto_tipo
    ADD CONSTRAINT base_posto_tipo_pkey PRIMARY KEY (id);


--
-- Name: base_utenza base_utenza_pkey; Type: CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_utenza
    ADD CONSTRAINT base_utenza_pkey PRIMARY KEY (id);


--
-- Name: sys_batch_log sys_batch_log_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_batch_log
    ADD CONSTRAINT sys_batch_log_pkey PRIMARY KEY (id);


--
-- Name: sys_dbchange sys_dbchange_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_dbchange
    ADD CONSTRAINT sys_dbchange_pkey PRIMARY KEY (ref);


--
-- Name: sys_error sys_error_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_error
    ADD CONSTRAINT sys_error_pkey PRIMARY KEY (id);


--
-- Name: sys_external_token sys_external_token_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_external_token
    ADD CONSTRAINT sys_external_token_pkey PRIMARY KEY (id);


--
-- Name: sys_external_token_use sys_external_token_use_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_external_token_use
    ADD CONSTRAINT sys_external_token_use_pkey PRIMARY KEY (id);


--
-- Name: sys_locked_record sys_locked_record_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_locked_record
    ADD CONSTRAINT sys_locked_record_pkey PRIMARY KEY (id);


--
-- Name: sys_service sys_service_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_service
    ADD CONSTRAINT sys_service_pkey PRIMARY KEY (service_identifier);


--
-- Name: sys_shared_object sys_shared_object_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_shared_object
    ADD CONSTRAINT sys_shared_object_pkey PRIMARY KEY (id);


--
-- Name: sys_task_execution sys_task_execution_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_task_execution
    ADD CONSTRAINT sys_task_execution_pkey PRIMARY KEY (id);


--
-- Name: sys_task sys_task_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_task
    ADD CONSTRAINT sys_task_pkey PRIMARY KEY (id);


--
-- Name: sys_task_result sys_task_result_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_task_result
    ADD CONSTRAINT sys_task_result_pkey PRIMARY KEY (id);


--
-- Name: sys_upgrade sys_upgrade_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_upgrade
    ADD CONSTRAINT sys_upgrade_pkey PRIMARY KEY (codekey);


--
-- Name: sys_widget sys_widget_hierarchical_pkey_key; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_widget
    ADD CONSTRAINT sys_widget_hierarchical_pkey_key UNIQUE (hierarchical_pkey);


--
-- Name: sys_widget sys_widget_pkey; Type: CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_widget
    ADD CONSTRAINT sys_widget_pkey PRIMARY KEY (id);


--
-- Name: adm_access_group___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_access_group___del_ts_idx ON adm.adm_access_group USING btree (__del_ts);


--
-- Name: adm_access_group___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_access_group___ins_ts_idx ON adm.adm_access_group USING btree (__ins_ts);


--
-- Name: adm_access_group___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_access_group___mod_ts_idx ON adm.adm_access_group USING btree (__mod_ts);


--
-- Name: adm_audit___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_audit___del_ts_idx ON adm.adm_audit USING btree (__del_ts);


--
-- Name: adm_audit___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_audit___ins_ts_idx ON adm.adm_audit USING btree (__ins_ts);


--
-- Name: adm_audit___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_audit___mod_ts_idx ON adm.adm_audit USING btree (__mod_ts);


--
-- Name: adm_authorization___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_authorization___del_ts_idx ON adm.adm_authorization USING btree (__del_ts);


--
-- Name: adm_authorization___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_authorization___ins_ts_idx ON adm.adm_authorization USING btree (__ins_ts);


--
-- Name: adm_authorization___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_authorization___mod_ts_idx ON adm.adm_authorization USING btree (__mod_ts);


--
-- Name: adm_authorization_user_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_authorization_user_id_idx ON adm.adm_authorization USING btree (user_id);


--
-- Name: adm_backup___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_backup___del_ts_idx ON adm.adm_backup USING btree (__del_ts);


--
-- Name: adm_backup___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_backup___ins_ts_idx ON adm.adm_backup USING btree (__ins_ts);


--
-- Name: adm_backup___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_backup___mod_ts_idx ON adm.adm_backup USING btree (__mod_ts);


--
-- Name: adm_ckstyle___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_ckstyle___del_ts_idx ON adm.adm_ckstyle USING btree (__del_ts);


--
-- Name: adm_ckstyle___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_ckstyle___ins_ts_idx ON adm.adm_ckstyle USING btree (__ins_ts);


--
-- Name: adm_ckstyle___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_ckstyle___mod_ts_idx ON adm.adm_ckstyle USING btree (__mod_ts);


--
-- Name: adm_connection_userid_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_connection_userid_idx ON adm.adm_connection USING btree (userid);


--
-- Name: adm_counter___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_counter___del_ts_idx ON adm.adm_counter USING btree (__del_ts);


--
-- Name: adm_counter___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_counter___ins_ts_idx ON adm.adm_counter USING btree (__ins_ts);


--
-- Name: adm_counter___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_counter___mod_ts_idx ON adm.adm_counter USING btree (__mod_ts);


--
-- Name: adm_counter_period_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_counter_period_idx ON adm.adm_counter USING btree (period);


--
-- Name: adm_group___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_group___del_ts_idx ON adm.adm_group USING btree (__del_ts);


--
-- Name: adm_group___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_group___ins_ts_idx ON adm.adm_group USING btree (__ins_ts);


--
-- Name: adm_group___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_group___mod_ts_idx ON adm.adm_group USING btree (__mod_ts);


--
-- Name: adm_htag___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htag___del_ts_idx ON adm.adm_htag USING btree (__del_ts);


--
-- Name: adm_htag___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htag___ins_ts_idx ON adm.adm_htag USING btree (__ins_ts);


--
-- Name: adm_htag___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htag___mod_ts_idx ON adm.adm_htag USING btree (__mod_ts);


--
-- Name: adm_htag___syscode_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE UNIQUE INDEX adm_htag___syscode_idx ON adm.adm_htag USING btree (__syscode);


--
-- Name: adm_htag_hierarchical_code_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE UNIQUE INDEX adm_htag_hierarchical_code_idx ON adm.adm_htag USING btree (hierarchical_code);


--
-- Name: adm_htag_hierarchical_pkey_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE UNIQUE INDEX adm_htag_hierarchical_pkey_idx ON adm.adm_htag USING btree (hierarchical_pkey);


--
-- Name: adm_htag_parent_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htag_parent_id_idx ON adm.adm_htag USING btree (parent_id);


--
-- Name: adm_htmltemplate___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate___del_ts_idx ON adm.adm_htmltemplate USING btree (__del_ts);


--
-- Name: adm_htmltemplate___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate___ins_ts_idx ON adm.adm_htmltemplate USING btree (__ins_ts);


--
-- Name: adm_htmltemplate___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate___mod_ts_idx ON adm.adm_htmltemplate USING btree (__mod_ts);


--
-- Name: adm_htmltemplate_atc___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate_atc___del_ts_idx ON adm.adm_htmltemplate_atc USING btree (__del_ts);


--
-- Name: adm_htmltemplate_atc_maintable_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate_atc_maintable_id_idx ON adm.adm_htmltemplate_atc USING btree (maintable_id);


--
-- Name: adm_htmltemplate_based_on_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate_based_on_idx ON adm.adm_htmltemplate USING btree (based_on);


--
-- Name: adm_htmltemplate_next_letterhead_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate_next_letterhead_id_idx ON adm.adm_htmltemplate USING btree (next_letterhead_id);


--
-- Name: adm_htmltemplate_type_code_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_htmltemplate_type_code_idx ON adm.adm_htmltemplate USING btree (type_code);


--
-- Name: adm_install_checklist___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_install_checklist___del_ts_idx ON adm.adm_install_checklist USING btree (__del_ts);


--
-- Name: adm_language___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_language___del_ts_idx ON adm.adm_language USING btree (__del_ts);


--
-- Name: adm_language___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_language___ins_ts_idx ON adm.adm_language USING btree (__ins_ts);


--
-- Name: adm_language___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_language___mod_ts_idx ON adm.adm_language USING btree (__mod_ts);


--
-- Name: adm_letterhead_type___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_letterhead_type___del_ts_idx ON adm.adm_letterhead_type USING btree (__del_ts);


--
-- Name: adm_letterhead_type___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_letterhead_type___ins_ts_idx ON adm.adm_letterhead_type USING btree (__ins_ts);


--
-- Name: adm_letterhead_type___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_letterhead_type___mod_ts_idx ON adm.adm_letterhead_type USING btree (__mod_ts);


--
-- Name: adm_menu___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu___del_ts_idx ON adm.adm_menu USING btree (__del_ts);


--
-- Name: adm_menu___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu___ins_ts_idx ON adm.adm_menu USING btree (__ins_ts);


--
-- Name: adm_menu___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu___mod_ts_idx ON adm.adm_menu USING btree (__mod_ts);


--
-- Name: adm_menu_hierarchical_pkey_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE UNIQUE INDEX adm_menu_hierarchical_pkey_idx ON adm.adm_menu USING btree (hierarchical_pkey);


--
-- Name: adm_menu_page___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu_page___del_ts_idx ON adm.adm_menu_page USING btree (__del_ts);


--
-- Name: adm_menu_page___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu_page___ins_ts_idx ON adm.adm_menu_page USING btree (__ins_ts);


--
-- Name: adm_menu_page___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu_page___mod_ts_idx ON adm.adm_menu_page USING btree (__mod_ts);


--
-- Name: adm_menu_page_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu_page_id_idx ON adm.adm_menu USING btree (page_id);


--
-- Name: adm_menu_parent_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_menu_parent_id_idx ON adm.adm_menu USING btree (parent_id);


--
-- Name: adm_notification___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_notification___del_ts_idx ON adm.adm_notification USING btree (__del_ts);


--
-- Name: adm_notification___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_notification___ins_ts_idx ON adm.adm_notification USING btree (__ins_ts);


--
-- Name: adm_notification___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_notification___mod_ts_idx ON adm.adm_notification USING btree (__mod_ts);


--
-- Name: adm_notification_letterhead_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_notification_letterhead_id_idx ON adm.adm_notification USING btree (letterhead_id);


--
-- Name: adm_pkginfo___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_pkginfo___del_ts_idx ON adm.adm_pkginfo USING btree (__del_ts);


--
-- Name: adm_pkginfo___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_pkginfo___ins_ts_idx ON adm.adm_pkginfo USING btree (__ins_ts);


--
-- Name: adm_pkginfo___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_pkginfo___mod_ts_idx ON adm.adm_pkginfo USING btree (__mod_ts);


--
-- Name: adm_preference___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_preference___del_ts_idx ON adm.adm_preference USING btree (__del_ts);


--
-- Name: adm_preference___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_preference___ins_ts_idx ON adm.adm_preference USING btree (__ins_ts);


--
-- Name: adm_preference___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_preference___mod_ts_idx ON adm.adm_preference USING btree (__mod_ts);


--
-- Name: adm_record_tag___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_record_tag___del_ts_idx ON adm.adm_record_tag USING btree (__del_ts);


--
-- Name: adm_record_tag___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_record_tag___ins_ts_idx ON adm.adm_record_tag USING btree (__ins_ts);


--
-- Name: adm_record_tag___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_record_tag___mod_ts_idx ON adm.adm_record_tag USING btree (__mod_ts);


--
-- Name: adm_sent_email___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_sent_email___del_ts_idx ON adm.adm_sent_email USING btree (__del_ts);


--
-- Name: adm_sent_email___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_sent_email___ins_ts_idx ON adm.adm_sent_email USING btree (__ins_ts);


--
-- Name: adm_sent_email___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_sent_email___mod_ts_idx ON adm.adm_sent_email USING btree (__mod_ts);


--
-- Name: adm_served_page_connection_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_served_page_connection_id_idx ON adm.adm_served_page USING btree (connection_id);


--
-- Name: adm_shortcut___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_shortcut___del_ts_idx ON adm.adm_shortcut USING btree (__del_ts);


--
-- Name: adm_shortcut___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_shortcut___ins_ts_idx ON adm.adm_shortcut USING btree (__ins_ts);


--
-- Name: adm_shortcut___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_shortcut___mod_ts_idx ON adm.adm_shortcut USING btree (__mod_ts);


--
-- Name: adm_tblinfo___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo___del_ts_idx ON adm.adm_tblinfo USING btree (__del_ts);


--
-- Name: adm_tblinfo___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo___ins_ts_idx ON adm.adm_tblinfo USING btree (__ins_ts);


--
-- Name: adm_tblinfo___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo___mod_ts_idx ON adm.adm_tblinfo USING btree (__mod_ts);


--
-- Name: adm_tblinfo_item___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo_item___del_ts_idx ON adm.adm_tblinfo_item USING btree (__del_ts);


--
-- Name: adm_tblinfo_item___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo_item___ins_ts_idx ON adm.adm_tblinfo_item USING btree (__ins_ts);


--
-- Name: adm_tblinfo_item___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo_item___mod_ts_idx ON adm.adm_tblinfo_item USING btree (__mod_ts);


--
-- Name: adm_tblinfo_item_tblid_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo_item_tblid_idx ON adm.adm_tblinfo_item USING btree (tblid);


--
-- Name: adm_tblinfo_pkgid_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_tblinfo_pkgid_idx ON adm.adm_tblinfo USING btree (pkgid);


--
-- Name: adm_user___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user___del_ts_idx ON adm.adm_user USING btree (__del_ts);


--
-- Name: adm_user___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user___ins_ts_idx ON adm.adm_user USING btree (__ins_ts);


--
-- Name: adm_user___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user___mod_ts_idx ON adm.adm_user USING btree (__mod_ts);


--
-- Name: adm_user_access_group___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_access_group___del_ts_idx ON adm.adm_user_access_group USING btree (__del_ts);


--
-- Name: adm_user_access_group___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_access_group___ins_ts_idx ON adm.adm_user_access_group USING btree (__ins_ts);


--
-- Name: adm_user_access_group___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_access_group___mod_ts_idx ON adm.adm_user_access_group USING btree (__mod_ts);


--
-- Name: adm_user_access_group_access_group_code_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_access_group_access_group_code_idx ON adm.adm_user_access_group USING btree (access_group_code);


--
-- Name: adm_user_access_group_user_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_access_group_user_id_idx ON adm.adm_user_access_group USING btree (user_id);


--
-- Name: adm_user_config___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_config___del_ts_idx ON adm.adm_user_config USING btree (__del_ts);


--
-- Name: adm_user_config___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_config___ins_ts_idx ON adm.adm_user_config USING btree (__ins_ts);


--
-- Name: adm_user_config___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_config___mod_ts_idx ON adm.adm_user_config USING btree (__mod_ts);


--
-- Name: adm_user_config_pkgid_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_config_pkgid_idx ON adm.adm_user_config USING btree (pkgid);


--
-- Name: adm_user_config_tblid_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_config_tblid_idx ON adm.adm_user_config USING btree (tblid);


--
-- Name: adm_user_config_user_group_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_config_user_group_idx ON adm.adm_user_config USING btree (user_group);


--
-- Name: adm_user_config_username_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_config_username_idx ON adm.adm_user_config USING btree (username);


--
-- Name: adm_user_group_code_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_group_code_idx ON adm.adm_user USING btree (group_code);


--
-- Name: adm_user_notification___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_notification___del_ts_idx ON adm.adm_user_notification USING btree (__del_ts);


--
-- Name: adm_user_notification___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_notification___ins_ts_idx ON adm.adm_user_notification USING btree (__ins_ts);


--
-- Name: adm_user_notification___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_notification___mod_ts_idx ON adm.adm_user_notification USING btree (__mod_ts);


--
-- Name: adm_user_notification_notification_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_notification_notification_id_idx ON adm.adm_user_notification USING btree (notification_id);


--
-- Name: adm_user_notification_user_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_notification_user_id_idx ON adm.adm_user_notification USING btree (user_id);


--
-- Name: adm_user_tag___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_tag___del_ts_idx ON adm.adm_user_tag USING btree (__del_ts);


--
-- Name: adm_user_tag___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_tag___ins_ts_idx ON adm.adm_user_tag USING btree (__ins_ts);


--
-- Name: adm_user_tag___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_tag___mod_ts_idx ON adm.adm_user_tag USING btree (__mod_ts);


--
-- Name: adm_user_tag_group_code_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_tag_group_code_idx ON adm.adm_user_tag USING btree (group_code);


--
-- Name: adm_user_tag_tag_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_tag_tag_id_idx ON adm.adm_user_tag USING btree (tag_id);


--
-- Name: adm_user_tag_user_id_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_user_tag_user_id_idx ON adm.adm_user_tag USING btree (user_id);


--
-- Name: adm_user_username_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE UNIQUE INDEX adm_user_username_idx ON adm.adm_user USING btree (username);


--
-- Name: adm_userobject___del_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject___del_ts_idx ON adm.adm_userobject USING btree (__del_ts);


--
-- Name: adm_userobject___ins_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject___ins_ts_idx ON adm.adm_userobject USING btree (__ins_ts);


--
-- Name: adm_userobject___mod_ts_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject___mod_ts_idx ON adm.adm_userobject USING btree (__mod_ts);


--
-- Name: adm_userobject_code_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject_code_idx ON adm.adm_userobject USING btree (code);


--
-- Name: adm_userobject_description_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject_description_idx ON adm.adm_userobject USING btree (description);


--
-- Name: adm_userobject_identifier_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE UNIQUE INDEX adm_userobject_identifier_idx ON adm.adm_userobject USING btree (identifier);


--
-- Name: adm_userobject_objtype_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject_objtype_idx ON adm.adm_userobject USING btree (objtype);


--
-- Name: adm_userobject_pkg_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject_pkg_idx ON adm.adm_userobject USING btree (pkg);


--
-- Name: adm_userobject_tbl_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject_tbl_idx ON adm.adm_userobject USING btree (tbl);


--
-- Name: adm_userobject_userid_idx; Type: INDEX; Schema: adm; Owner: postgres
--

CREATE INDEX adm_userobject_userid_idx ON adm.adm_userobject USING btree (userid);


--
-- Name: base_casa___del_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_casa___del_ts_idx ON base.base_casa USING btree (__del_ts);


--
-- Name: base_casa___ins_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_casa___ins_ts_idx ON base.base_casa USING btree (__ins_ts);


--
-- Name: base_casa___mod_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_casa___mod_ts_idx ON base.base_casa USING btree (__mod_ts);


--
-- Name: base_locazione___del_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_locazione___del_ts_idx ON base.base_locazione USING btree (__del_ts);


--
-- Name: base_locazione___ins_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_locazione___ins_ts_idx ON base.base_locazione USING btree (__ins_ts);


--
-- Name: base_locazione___mod_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_locazione___mod_ts_idx ON base.base_locazione USING btree (__mod_ts);


--
-- Name: base_locazione_casa_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_locazione_casa_id_idx ON base.base_locazione USING btree (casa_id);


--
-- Name: base_locazione_hierarchical_pkey_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE UNIQUE INDEX base_locazione_hierarchical_pkey_idx ON base.base_locazione USING btree (hierarchical_pkey);


--
-- Name: base_locazione_parent_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_locazione_parent_id_idx ON base.base_locazione USING btree (parent_id);


--
-- Name: base_oggetto___del_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto___del_ts_idx ON base.base_oggetto USING btree (__del_ts);


--
-- Name: base_oggetto___ins_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto___ins_ts_idx ON base.base_oggetto USING btree (__ins_ts);


--
-- Name: base_oggetto___mod_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto___mod_ts_idx ON base.base_oggetto USING btree (__mod_ts);


--
-- Name: base_oggetto_casa_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_casa_id_idx ON base.base_oggetto USING btree (casa_id);


--
-- Name: base_oggetto_categoria___del_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria___del_ts_idx ON base.base_oggetto_categoria USING btree (__del_ts);


--
-- Name: base_oggetto_categoria___ins_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria___ins_ts_idx ON base.base_oggetto_categoria USING btree (__ins_ts);


--
-- Name: base_oggetto_categoria___mod_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria___mod_ts_idx ON base.base_oggetto_categoria USING btree (__mod_ts);


--
-- Name: base_oggetto_categoria_casa_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria_casa_id_idx ON base.base_oggetto_categoria USING btree (casa_id);


--
-- Name: base_oggetto_categoria_hierarchical_pkey_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE UNIQUE INDEX base_oggetto_categoria_hierarchical_pkey_idx ON base.base_oggetto_categoria USING btree (hierarchical_pkey);


--
-- Name: base_oggetto_categoria_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria_id_idx ON base.base_oggetto USING btree (categoria_id);


--
-- Name: base_oggetto_categoria_parent_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria_parent_id_idx ON base.base_oggetto_categoria USING btree (parent_id);


--
-- Name: base_oggetto_categoria_posto_id_def_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria_posto_id_def_idx ON base.base_oggetto_categoria USING btree (posto_id_def);


--
-- Name: base_oggetto_categoria_posto_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_categoria_posto_id_idx ON base.base_oggetto_categoria USING btree (posto_id);


--
-- Name: base_oggetto_locazione_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_locazione_id_idx ON base.base_oggetto USING btree (locazione_id);


--
-- Name: base_oggetto_posto_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_oggetto_posto_id_idx ON base.base_oggetto USING btree (posto_id);


--
-- Name: base_posto___del_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto___del_ts_idx ON base.base_posto USING btree (__del_ts);


--
-- Name: base_posto___ins_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto___ins_ts_idx ON base.base_posto USING btree (__ins_ts);


--
-- Name: base_posto___mod_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto___mod_ts_idx ON base.base_posto USING btree (__mod_ts);


--
-- Name: base_posto_casa_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto_casa_id_idx ON base.base_posto USING btree (casa_id);


--
-- Name: base_posto_hierarchical_pkey_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE UNIQUE INDEX base_posto_hierarchical_pkey_idx ON base.base_posto USING btree (hierarchical_pkey);


--
-- Name: base_posto_parent_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto_parent_id_idx ON base.base_posto USING btree (parent_id);


--
-- Name: base_posto_posto_tipo_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto_posto_tipo_id_idx ON base.base_posto USING btree (posto_tipo_id);


--
-- Name: base_posto_tipo___del_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto_tipo___del_ts_idx ON base.base_posto_tipo USING btree (__del_ts);


--
-- Name: base_posto_tipo___ins_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto_tipo___ins_ts_idx ON base.base_posto_tipo USING btree (__ins_ts);


--
-- Name: base_posto_tipo___mod_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_posto_tipo___mod_ts_idx ON base.base_posto_tipo USING btree (__mod_ts);


--
-- Name: base_utenza___del_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_utenza___del_ts_idx ON base.base_utenza USING btree (__del_ts);


--
-- Name: base_utenza___ins_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_utenza___ins_ts_idx ON base.base_utenza USING btree (__ins_ts);


--
-- Name: base_utenza___mod_ts_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_utenza___mod_ts_idx ON base.base_utenza USING btree (__mod_ts);


--
-- Name: base_utenza_casa_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_utenza_casa_id_idx ON base.base_utenza USING btree (casa_id);


--
-- Name: base_utenza_user_id_idx; Type: INDEX; Schema: base; Owner: postgres
--

CREATE INDEX base_utenza_user_id_idx ON base.base_utenza USING btree (user_id);


--
-- Name: sys_batch_log___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_batch_log___del_ts_idx ON sys.sys_batch_log USING btree (__del_ts);


--
-- Name: sys_batch_log___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_batch_log___ins_ts_idx ON sys.sys_batch_log USING btree (__ins_ts);


--
-- Name: sys_batch_log___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_batch_log___mod_ts_idx ON sys.sys_batch_log USING btree (__mod_ts);


--
-- Name: sys_batch_log_page_id_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_batch_log_page_id_idx ON sys.sys_batch_log USING btree (page_id);


--
-- Name: sys_dbchange___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_dbchange___ins_ts_idx ON sys.sys_dbchange USING btree (__ins_ts);


--
-- Name: sys_error___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_error___del_ts_idx ON sys.sys_error USING btree (__del_ts);


--
-- Name: sys_error___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_error___ins_ts_idx ON sys.sys_error USING btree (__ins_ts);


--
-- Name: sys_error___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_error___mod_ts_idx ON sys.sys_error USING btree (__mod_ts);


--
-- Name: sys_external_token_connection_id_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_external_token_connection_id_idx ON sys.sys_external_token USING btree (connection_id);


--
-- Name: sys_external_token_exec_user_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_external_token_exec_user_idx ON sys.sys_external_token USING btree (exec_user);


--
-- Name: sys_external_token_use_external_token_id_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_external_token_use_external_token_id_idx ON sys.sys_external_token_use USING btree (external_token_id);


--
-- Name: sys_locked_record_lock_table_lock_pkey_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE UNIQUE INDEX sys_locked_record_lock_table_lock_pkey_idx ON sys.sys_locked_record USING btree (lock_table, lock_pkey);


--
-- Name: sys_service___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_service___del_ts_idx ON sys.sys_service USING btree (__del_ts);


--
-- Name: sys_service___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_service___ins_ts_idx ON sys.sys_service USING btree (__ins_ts);


--
-- Name: sys_service___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_service___mod_ts_idx ON sys.sys_service USING btree (__mod_ts);


--
-- Name: sys_shared_object___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_shared_object___del_ts_idx ON sys.sys_shared_object USING btree (__del_ts);


--
-- Name: sys_shared_object___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_shared_object___ins_ts_idx ON sys.sys_shared_object USING btree (__ins_ts);


--
-- Name: sys_shared_object___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_shared_object___mod_ts_idx ON sys.sys_shared_object USING btree (__mod_ts);


--
-- Name: sys_shared_object_description_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_shared_object_description_idx ON sys.sys_shared_object USING btree (description);


--
-- Name: sys_task___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task___del_ts_idx ON sys.sys_task USING btree (__del_ts);


--
-- Name: sys_task___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task___ins_ts_idx ON sys.sys_task USING btree (__ins_ts);


--
-- Name: sys_task___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task___mod_ts_idx ON sys.sys_task USING btree (__mod_ts);


--
-- Name: sys_task_execution___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution___del_ts_idx ON sys.sys_task_execution USING btree (__del_ts);


--
-- Name: sys_task_execution___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution___ins_ts_idx ON sys.sys_task_execution USING btree (__ins_ts);


--
-- Name: sys_task_execution___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution___mod_ts_idx ON sys.sys_task_execution USING btree (__mod_ts);


--
-- Name: sys_task_execution_end_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution_end_ts_idx ON sys.sys_task_execution USING btree (end_ts);


--
-- Name: sys_task_execution_is_error_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution_is_error_idx ON sys.sys_task_execution USING btree (is_error);


--
-- Name: sys_task_execution_reasonkey_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution_reasonkey_idx ON sys.sys_task_execution USING btree (reasonkey);


--
-- Name: sys_task_execution_start_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution_start_ts_idx ON sys.sys_task_execution USING btree (start_ts);


--
-- Name: sys_task_execution_task_id_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_execution_task_id_idx ON sys.sys_task_execution USING btree (task_id);


--
-- Name: sys_task_last_scheduled_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_last_scheduled_ts_idx ON sys.sys_task USING btree (last_scheduled_ts);


--
-- Name: sys_task_result___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_result___del_ts_idx ON sys.sys_task_result USING btree (__del_ts);


--
-- Name: sys_task_result___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_result___ins_ts_idx ON sys.sys_task_result USING btree (__ins_ts);


--
-- Name: sys_task_result___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_result___mod_ts_idx ON sys.sys_task_result USING btree (__mod_ts);


--
-- Name: sys_task_result_task_id_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_result_task_id_idx ON sys.sys_task_result USING btree (task_id);


--
-- Name: sys_task_user_id_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_user_id_idx ON sys.sys_task USING btree (user_id);


--
-- Name: sys_task_worker_code_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_task_worker_code_idx ON sys.sys_task USING btree (worker_code);


--
-- Name: sys_upgrade___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_upgrade___del_ts_idx ON sys.sys_upgrade USING btree (__del_ts);


--
-- Name: sys_upgrade___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_upgrade___ins_ts_idx ON sys.sys_upgrade USING btree (__ins_ts);


--
-- Name: sys_upgrade___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_upgrade___mod_ts_idx ON sys.sys_upgrade USING btree (__mod_ts);


--
-- Name: sys_widget___del_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_widget___del_ts_idx ON sys.sys_widget USING btree (__del_ts);


--
-- Name: sys_widget___ins_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_widget___ins_ts_idx ON sys.sys_widget USING btree (__ins_ts);


--
-- Name: sys_widget___mod_ts_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_widget___mod_ts_idx ON sys.sys_widget USING btree (__mod_ts);


--
-- Name: sys_widget_hierarchical_pkey_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE UNIQUE INDEX sys_widget_hierarchical_pkey_idx ON sys.sys_widget USING btree (hierarchical_pkey);


--
-- Name: sys_widget_parent_id_idx; Type: INDEX; Schema: sys; Owner: postgres
--

CREATE INDEX sys_widget_parent_id_idx ON sys.sys_widget USING btree (parent_id);


--
-- Name: adm_authorization fk_adm_authorization_user_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_authorization
    ADD CONSTRAINT fk_adm_authorization_user_id FOREIGN KEY (user_id) REFERENCES adm.adm_user(id) ON UPDATE CASCADE;


--
-- Name: adm_htag fk_adm_htag_parent_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htag
    ADD CONSTRAINT fk_adm_htag_parent_id FOREIGN KEY (parent_id) REFERENCES adm.adm_htag(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adm_htmltemplate_atc fk_adm_htmltemplate_atc_maintable_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htmltemplate_atc
    ADD CONSTRAINT fk_adm_htmltemplate_atc_maintable_id FOREIGN KEY (maintable_id) REFERENCES adm.adm_htmltemplate(id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adm_htmltemplate fk_adm_htmltemplate_based_on; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htmltemplate
    ADD CONSTRAINT fk_adm_htmltemplate_based_on FOREIGN KEY (based_on) REFERENCES adm.adm_htmltemplate(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adm_htmltemplate fk_adm_htmltemplate_next_letterhead_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htmltemplate
    ADD CONSTRAINT fk_adm_htmltemplate_next_letterhead_id FOREIGN KEY (next_letterhead_id) REFERENCES adm.adm_htmltemplate(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adm_htmltemplate fk_adm_htmltemplate_type_code; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_htmltemplate
    ADD CONSTRAINT fk_adm_htmltemplate_type_code FOREIGN KEY (type_code) REFERENCES adm.adm_letterhead_type(code) ON UPDATE CASCADE;


--
-- Name: adm_menu fk_adm_menu_page_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_menu
    ADD CONSTRAINT fk_adm_menu_page_id FOREIGN KEY (page_id) REFERENCES adm.adm_menu_page(id) ON UPDATE CASCADE;


--
-- Name: adm_menu fk_adm_menu_parent_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_menu
    ADD CONSTRAINT fk_adm_menu_parent_id FOREIGN KEY (parent_id) REFERENCES adm.adm_menu(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adm_notification fk_adm_notification_letterhead_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_notification
    ADD CONSTRAINT fk_adm_notification_letterhead_id FOREIGN KEY (letterhead_id) REFERENCES adm.adm_htmltemplate(id) ON UPDATE CASCADE;


--
-- Name: adm_served_page fk_adm_served_page_connection_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_served_page
    ADD CONSTRAINT fk_adm_served_page_connection_id FOREIGN KEY (connection_id) REFERENCES adm.adm_connection(id) ON UPDATE CASCADE;


--
-- Name: adm_tblinfo_item fk_adm_tblinfo_item_tblid; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_tblinfo_item
    ADD CONSTRAINT fk_adm_tblinfo_item_tblid FOREIGN KEY (tblid) REFERENCES adm.adm_tblinfo(tblid) ON UPDATE CASCADE;


--
-- Name: adm_user_access_group fk_adm_user_access_group_access_group_code; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_access_group
    ADD CONSTRAINT fk_adm_user_access_group_access_group_code FOREIGN KEY (access_group_code) REFERENCES adm.adm_access_group(code) ON UPDATE CASCADE;


--
-- Name: adm_user_access_group fk_adm_user_access_group_user_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_access_group
    ADD CONSTRAINT fk_adm_user_access_group_user_id FOREIGN KEY (user_id) REFERENCES adm.adm_user(id) ON UPDATE CASCADE;


--
-- Name: adm_user_config fk_adm_user_config_pkgid; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_config
    ADD CONSTRAINT fk_adm_user_config_pkgid FOREIGN KEY (pkgid) REFERENCES adm.adm_pkginfo(pkgid) ON UPDATE CASCADE;


--
-- Name: adm_user_config fk_adm_user_config_tblid; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_config
    ADD CONSTRAINT fk_adm_user_config_tblid FOREIGN KEY (tblid) REFERENCES adm.adm_tblinfo(tblid) ON UPDATE CASCADE;


--
-- Name: adm_user_config fk_adm_user_config_user_group; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_config
    ADD CONSTRAINT fk_adm_user_config_user_group FOREIGN KEY (user_group) REFERENCES adm.adm_group(code) ON UPDATE CASCADE;


--
-- Name: adm_user fk_adm_user_group_code; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user
    ADD CONSTRAINT fk_adm_user_group_code FOREIGN KEY (group_code) REFERENCES adm.adm_group(code) ON UPDATE CASCADE;


--
-- Name: adm_user_notification fk_adm_user_notification_notification_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_notification
    ADD CONSTRAINT fk_adm_user_notification_notification_id FOREIGN KEY (notification_id) REFERENCES adm.adm_notification(id) ON UPDATE CASCADE;


--
-- Name: adm_user_notification fk_adm_user_notification_user_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_notification
    ADD CONSTRAINT fk_adm_user_notification_user_id FOREIGN KEY (user_id) REFERENCES adm.adm_user(id) ON UPDATE CASCADE;


--
-- Name: adm_user_tag fk_adm_user_tag_group_code; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_tag
    ADD CONSTRAINT fk_adm_user_tag_group_code FOREIGN KEY (group_code) REFERENCES adm.adm_group(code) ON UPDATE CASCADE;


--
-- Name: adm_user_tag fk_adm_user_tag_tag_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_tag
    ADD CONSTRAINT fk_adm_user_tag_tag_id FOREIGN KEY (tag_id) REFERENCES adm.adm_htag(id) ON UPDATE CASCADE;


--
-- Name: adm_user_tag fk_adm_user_tag_user_id; Type: FK CONSTRAINT; Schema: adm; Owner: postgres
--

ALTER TABLE ONLY adm.adm_user_tag
    ADD CONSTRAINT fk_adm_user_tag_user_id FOREIGN KEY (user_id) REFERENCES adm.adm_user(id) ON UPDATE CASCADE;


--
-- Name: base_locazione fk_base_locazione_parent_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_locazione
    ADD CONSTRAINT fk_base_locazione_parent_id FOREIGN KEY (parent_id) REFERENCES base.base_locazione(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: base_oggetto fk_base_oggetto_casa_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto
    ADD CONSTRAINT fk_base_oggetto_casa_id FOREIGN KEY (casa_id) REFERENCES base.base_casa(id) ON UPDATE CASCADE;


--
-- Name: base_oggetto_categoria fk_base_oggetto_categoria_casa_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto_categoria
    ADD CONSTRAINT fk_base_oggetto_categoria_casa_id FOREIGN KEY (casa_id) REFERENCES base.base_casa(id) ON UPDATE CASCADE;


--
-- Name: base_oggetto fk_base_oggetto_categoria_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto
    ADD CONSTRAINT fk_base_oggetto_categoria_id FOREIGN KEY (categoria_id) REFERENCES base.base_oggetto_categoria(id) ON UPDATE CASCADE;


--
-- Name: base_oggetto_categoria fk_base_oggetto_categoria_parent_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto_categoria
    ADD CONSTRAINT fk_base_oggetto_categoria_parent_id FOREIGN KEY (parent_id) REFERENCES base.base_oggetto_categoria(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: base_oggetto_categoria fk_base_oggetto_categoria_posto_id_def; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto_categoria
    ADD CONSTRAINT fk_base_oggetto_categoria_posto_id_def FOREIGN KEY (posto_id_def) REFERENCES base.base_posto(id) ON UPDATE CASCADE;


--
-- Name: base_oggetto fk_base_oggetto_posto_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_oggetto
    ADD CONSTRAINT fk_base_oggetto_posto_id FOREIGN KEY (posto_id) REFERENCES base.base_posto(id) ON UPDATE CASCADE;


--
-- Name: base_posto fk_base_posto_parent_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_posto
    ADD CONSTRAINT fk_base_posto_parent_id FOREIGN KEY (parent_id) REFERENCES base.base_posto(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: base_posto fk_base_posto_posto_tipo_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_posto
    ADD CONSTRAINT fk_base_posto_posto_tipo_id FOREIGN KEY (posto_tipo_id) REFERENCES base.base_posto_tipo(id) ON UPDATE CASCADE;


--
-- Name: base_utenza fk_base_utenza_user_id; Type: FK CONSTRAINT; Schema: base; Owner: postgres
--

ALTER TABLE ONLY base.base_utenza
    ADD CONSTRAINT fk_base_utenza_user_id FOREIGN KEY (user_id) REFERENCES adm.adm_user(id) ON UPDATE CASCADE;


--
-- Name: sys_external_token_use fk_sys_external_token_use_external_token_id; Type: FK CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_external_token_use
    ADD CONSTRAINT fk_sys_external_token_use_external_token_id FOREIGN KEY (external_token_id) REFERENCES sys.sys_external_token(id) ON UPDATE CASCADE;


--
-- Name: sys_task_execution fk_sys_task_execution_task_id; Type: FK CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_task_execution
    ADD CONSTRAINT fk_sys_task_execution_task_id FOREIGN KEY (task_id) REFERENCES sys.sys_task(id) ON UPDATE CASCADE;


--
-- Name: sys_task_result fk_sys_task_result_task_id; Type: FK CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_task_result
    ADD CONSTRAINT fk_sys_task_result_task_id FOREIGN KEY (task_id) REFERENCES sys.sys_task(id) ON UPDATE CASCADE;


--
-- Name: sys_task fk_sys_task_user_id; Type: FK CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_task
    ADD CONSTRAINT fk_sys_task_user_id FOREIGN KEY (user_id) REFERENCES adm.adm_user(id) ON UPDATE CASCADE;


--
-- Name: sys_widget fk_sys_widget_parent_id; Type: FK CONSTRAINT; Schema: sys; Owner: postgres
--

ALTER TABLE ONLY sys.sys_widget
    ADD CONSTRAINT fk_sys_widget_parent_id FOREIGN KEY (parent_id) REFERENCES sys.sys_widget(id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

